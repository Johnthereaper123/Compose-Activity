package com.example.gridcomposeapp

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.gridcomposeapp.ui.theme.AppButton
import com.example.gridcomposeapp.ui.theme.AppTextField
import com.example.gridcomposeapp.ui.theme.AppTitle

data class InsertRowsScreenState(
    val rows: String = ""
)

@Composable
fun InsertRowsScreenContent(
    state: InsertRowsScreenState,
    onRowsChange: (String) -> Unit,
    onNextClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Scaffold { paddingValues ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            AppTitle("Insert Number of Rows")

            Spacer(modifier = Modifier.weight(1f))

            AppTextField(
                value = state.rows,
                onValueChange = onRowsChange,
                label = "Number of rows"
            )

            Spacer(modifier = Modifier.weight(1f))

            AppButton(
                text = "Next",
                onClick = onNextClick,
                enabled = state.rows.isNotEmpty() && state.rows.toIntOrNull() != null
            )
        }
    }
}

@Composable
fun InsertRowsScreen(
    navController: NavController,
    modifier: Modifier = Modifier
) {
    var rows by rememberSaveable { mutableStateOf("") }

    val state = InsertRowsScreenState(rows = rows)

    InsertRowsScreenContent(
        state = state,
        onRowsChange = { rows = it },
        onNextClick = {
            navController.navigate("insertColumns/${rows}")
        },
        modifier = modifier
    )
}